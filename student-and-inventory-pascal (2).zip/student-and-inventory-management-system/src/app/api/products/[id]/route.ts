import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products, systemLogs } from "@/db/schema";
import { eq, and, ne } from "drizzle-orm";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const numId = parseInt(id, 10);
    if (isNaN(numId)) {
      return NextResponse.json({ success: false, error: "Invalid product ID" }, { status: 400 });
    }

    const [product] = await db.select().from(products).where(eq(products.id, numId)).limit(1);
    if (!product) {
      return NextResponse.json({ success: false, error: "Product not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, product });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const numId = parseInt(id, 10);
    if (isNaN(numId)) {
      return NextResponse.json({ success: false, error: "Invalid product ID" }, { status: 400 });
    }

    const body = await req.json();
    const { productId, productName, category, unitPrice, quantity } = body;

    if (!productId || !productId.trim()) {
      return NextResponse.json({ success: false, error: "Product ID is required." }, { status: 400 });
    }
    if (!productName || !productName.trim()) {
      return NextResponse.json({ success: false, error: "Product Name is required." }, { status: 400 });
    }

    const price = Number(unitPrice);
    const qty = parseInt(quantity, 10);

    if (isNaN(price) || price < 0 || isNaN(qty) || qty < 0) {
      return NextResponse.json({ success: false, error: "Price and quantity must be non-negative numbers." }, { status: 400 });
    }

    const cleanProductId = productId.trim().toUpperCase();

    // Check duplicate
    const duplicate = await db
      .select()
      .from(products)
      .where(and(eq(products.productId, cleanProductId), ne(products.id, numId)))
      .limit(1);

    if (duplicate.length > 0) {
      return NextResponse.json(
        { success: false, error: `Product ID '${cleanProductId}' already belongs to another product.` },
        { status: 409 }
      );
    }

    const [updated] = await db
      .update(products)
      .set({
        productId: cleanProductId,
        productName: productName.trim(),
        category: category?.trim() || "General",
        unitPrice: Number(price.toFixed(2)),
        quantity: qty,
        updatedAt: new Date(),
      })
      .where(eq(products.id, numId))
      .returning();

    await db.insert(systemLogs).values({
      action: "PRODUCT_UPDATED",
      module: "INVENTORY",
      details: `Updated product ${updated.productName} (${updated.productId})`,
    });

    return NextResponse.json({ success: true, product: updated });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const numId = parseInt(id, 10);
    if (isNaN(numId)) {
      return NextResponse.json({ success: false, error: "Invalid product ID" }, { status: 400 });
    }

    const [existing] = await db.select().from(products).where(eq(products.id, numId)).limit(1);
    if (!existing) {
      return NextResponse.json({ success: false, error: "Product not found" }, { status: 404 });
    }

    await db.delete(products).where(eq(products.id, numId));

    await db.insert(systemLogs).values({
      action: "PRODUCT_DELETED",
      module: "INVENTORY",
      details: `Deleted product ${existing.productName} (${existing.productId})`,
    });

    return NextResponse.json({ success: true, message: `Product ${existing.productName} removed from inventory.` });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
