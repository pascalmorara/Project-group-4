import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products, systemLogs } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const query = searchParams.get("q")?.trim().toLowerCase();

    const allProducts = await db.select().from(products).orderBy(desc(products.createdAt));

    if (query) {
      const filtered = allProducts.filter(
        (p) =>
          p.productId.toLowerCase().includes(query) ||
          p.productName.toLowerCase().includes(query) ||
          p.category.toLowerCase().includes(query)
      );
      return NextResponse.json({ success: true, products: filtered });
    }

    return NextResponse.json({ success: true, products: allProducts });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { productId, productName, category, unitPrice, quantity } = body;

    if (!productId || typeof productId !== "string" || !productId.trim()) {
      return NextResponse.json({ success: false, error: "Product ID is required and cannot be blank." }, { status: 400 });
    }

    if (!productName || typeof productName !== "string" || !productName.trim()) {
      return NextResponse.json({ success: false, error: "Product Name is required and cannot be blank." }, { status: 400 });
    }

    const price = Number(unitPrice);
    const qty = parseInt(quantity, 10);

    if (isNaN(price) || price < 0) {
      return NextResponse.json({ success: false, error: "Unit Price must be a non-negative number." }, { status: 400 });
    }

    if (isNaN(qty) || qty < 0) {
      return NextResponse.json({ success: false, error: "Quantity must be a non-negative integer." }, { status: 400 });
    }

    const cleanProductId = productId.trim().toUpperCase();

    // Check duplicate
    const existing = await db
      .select()
      .from(products)
      .where(eq(products.productId, cleanProductId))
      .limit(1);

    if (existing.length > 0) {
      return NextResponse.json(
        { success: false, error: `Product with ID '${cleanProductId}' already exists in inventory.` },
        { status: 409 }
      );
    }

    const [newProduct] = await db
      .insert(products)
      .values({
        productId: cleanProductId,
        productName: productName.trim(),
        category: category?.trim() || "General",
        unitPrice: Number(price.toFixed(2)),
        quantity: qty,
      })
      .returning();

    await db.insert(systemLogs).values({
      action: "PRODUCT_CREATED",
      module: "INVENTORY",
      details: `Added new product ${newProduct.productName} (${newProduct.productId}), stock: ${qty}, price: $${price.toFixed(2)}`,
    });

    return NextResponse.json({ success: true, product: newProduct }, { status: 201 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
