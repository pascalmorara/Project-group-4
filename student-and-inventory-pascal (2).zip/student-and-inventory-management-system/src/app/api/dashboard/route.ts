import { NextResponse } from "next/server";
import { db } from "@/db";
import { students, products, stockTransactions } from "@/db/schema";
import { seedInitialData } from "@/db/seed";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    await seedInitialData();

    const allStudents = await db.select().from(students).orderBy(desc(students.createdAt));
    const allProducts = await db.select().from(products).orderBy(desc(products.createdAt));
    const allTransactions = await db.select().from(stockTransactions).orderBy(desc(stockTransactions.transactionDate)).limit(10);

    // Academic Calculations
    const totalStudents = allStudents.length;
    const passedStudents = allStudents.filter((s) => s.status === "PASS").length;
    const failedStudents = allStudents.filter((s) => s.status === "FAIL").length;
    
    let classAverage = 0;
    let highestScore = 0;
    let lowestScore = 0;

    if (totalStudents > 0) {
      const scores = allStudents.map((s) => s.totalScore);
      const sum = scores.reduce((acc, curr) => acc + curr, 0);
      classAverage = Number((sum / totalStudents).toFixed(2));
      highestScore = Math.max(...scores);
      lowestScore = Math.min(...scores);
    }

    const gradeCounts = {
      A: allStudents.filter((s) => s.grade === "A").length,
      B: allStudents.filter((s) => s.grade === "B").length,
      C: allStudents.filter((s) => s.grade === "C").length,
      D: allStudents.filter((s) => s.grade === "D").length,
      E: allStudents.filter((s) => s.grade === "E").length,
    };

    // Inventory Calculations
    const totalProducts = allProducts.length;
    let totalUnits = 0;
    let totalInventoryValue = 0;
    let lowStockCount = 0;
    let outOfStockCount = 0;
    let highestValueProduct: { name: string; value: number } | null = null;
    let maxVal = -1;

    for (const p of allProducts) {
      totalUnits += p.quantity;
      const val = p.unitPrice * p.quantity;
      totalInventoryValue += val;

      if (p.quantity === 0) {
        outOfStockCount++;
      } else if (p.quantity < 10) {
        lowStockCount++;
      }

      if (val > maxVal) {
        maxVal = val;
        highestValueProduct = { name: p.productName, value: Number(val.toFixed(2)) };
      }
    }

    totalInventoryValue = Number(totalInventoryValue.toFixed(2));

    const categoryBreakdown: Record<string, { count: number; totalValue: number }> = {};
    for (const p of allProducts) {
      const cat = p.category || "General";
      if (!categoryBreakdown[cat]) {
        categoryBreakdown[cat] = { count: 0, totalValue: 0 };
      }
      categoryBreakdown[cat].count += 1;
      categoryBreakdown[cat].totalValue = Number((categoryBreakdown[cat].totalValue + p.unitPrice * p.quantity).toFixed(2));
    }

    return NextResponse.json({
      success: true,
      academic: {
        totalStudents,
        passedStudents,
        failedStudents,
        classAverage,
        highestScore,
        lowestScore,
        passRate: totalStudents > 0 ? Number(((passedStudents / totalStudents) * 100).toFixed(1)) : 0,
        gradeCounts,
      },
      inventory: {
        totalProducts,
        totalUnits,
        totalInventoryValue,
        lowStockCount,
        outOfStockCount,
        normalStockCount: totalProducts - lowStockCount - outOfStockCount,
        highestValueProduct,
        categoryBreakdown,
      },
      recentStudents: allStudents.slice(0, 5),
      recentTransactions: allTransactions,
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
