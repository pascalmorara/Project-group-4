import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { students, products, stockTransactions, systemLogs } from "@/db/schema";

export async function GET() {
  try {
    const allStudents = await db.select().from(students);
    const allProducts = await db.select().from(products);
    const allTx = await db.select().from(stockTransactions);
    const allLogs = await db.select().from(systemLogs);

    const backupData = {
      system: "GROUP 4 PROJECT",
      version: "2.5.0-ENTERPRISE",
      exportedAt: new Date().toISOString(),
      counts: {
        students: allStudents.length,
        products: allProducts.length,
        transactions: allTx.length,
        logs: allLogs.length,
      },
      data: {
        students: allStudents,
        products: allProducts,
        transactions: allTx,
        logs: allLogs,
      },
    };

    return NextResponse.json(backupData);
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    if (!body?.data?.students || !body?.data?.products) {
      return NextResponse.json(
        { success: false, error: "Invalid backup file structure. Must contain 'students' and 'products' collections." },
        { status: 400 }
      );
    }

    // Clear existing
    await db.delete(stockTransactions);
    await db.delete(students);
    await db.delete(products);
    await db.delete(systemLogs);

    // Insert backup students
    if (body.data.students.length > 0) {
      const studentInserts = body.data.students.map((s: any) => ({
        registrationNumber: s.registrationNumber,
        fullName: s.fullName,
        cat1: Number(s.cat1),
        cat2: Number(s.cat2),
        examination: Number(s.examination),
        totalScore: Number(s.totalScore),
        grade: s.grade,
        status: s.status,
      }));
      await db.insert(students).values(studentInserts);
    }

    // Insert backup products
    if (body.data.products.length > 0) {
      const productInserts = body.data.products.map((p: any) => ({
        productId: p.productId,
        productName: p.productName,
        category: p.category || "General",
        unitPrice: Number(p.unitPrice),
        quantity: parseInt(p.quantity, 10),
      }));
      await db.insert(products).values(productInserts);
    }

    // Insert backup transactions
    if (body.data.transactions?.length > 0) {
      const txInserts = body.data.transactions.map((t: any) => ({
        transactionId: t.transactionId,
        productId: t.productId,
        productName: t.productName,
        transactionType: t.transactionType,
        quantity: parseInt(t.quantity, 10),
        previousStock: parseInt(t.previousStock, 10),
        updatedStock: parseInt(t.updatedStock, 10),
        notes: t.notes || "",
      }));
      await db.insert(stockTransactions).values(txInserts);
    }

    await db.insert(systemLogs).values({
      action: "DATABASE_RESTORED",
      module: "SYSTEM",
      details: `Database restored from backup containing ${body.data.students.length} students and ${body.data.products.length} products.`,
    });

    return NextResponse.json({
      success: true,
      message: `Database successfully restored (${body.data.students.length} students, ${body.data.products.length} products, ${body.data.transactions?.length || 0} transactions).`,
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
