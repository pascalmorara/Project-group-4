import { NextResponse } from "next/server";
import { db } from "@/db";
import { students, products, stockTransactions, systemLogs } from "@/db/schema";
import { seedInitialData } from "@/db/seed";

export async function POST() {
  try {
    // Delete all records
    await db.delete(stockTransactions);
    await db.delete(students);
    await db.delete(products);
    await db.delete(systemLogs);

    // Reseed
    await seedInitialData();

    await db.insert(systemLogs).values({
      action: "DATABASE_RESET",
      module: "SYSTEM",
      details: "Database reset and re-seeded with official SOEN 105 demo data.",
    });

    return NextResponse.json({ success: true, message: "Database reset and seeded successfully." });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
