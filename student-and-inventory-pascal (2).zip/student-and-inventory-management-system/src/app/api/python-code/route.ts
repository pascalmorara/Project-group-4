import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";

const allowedFiles: Record<string, string> = {
  "main.py": "main.py",
  "database/database.py": "database/database.py",
  "database/schema.sql": "database/schema.sql",
  "modules/students.py": "modules/students.py",
  "modules/inventory.py": "modules/inventory.py",
  "modules/transactions.py": "modules/transactions.py",
  "modules/searching.py": "modules/searching.py",
  "modules/sorting.py": "modules/sorting.py",
  "modules/reports.py": "modules/reports.py",
  "interface/themes.py": "interface/themes.py",
  "utilities/calculations.py": "utilities/calculations.py",
  "utilities/validators.py": "utilities/validators.py",
  "utilities/exporters.py": "utilities/exporters.py",
  "tests/test_students.py": "tests/test_students.py",
  "tests/test_inventory.py": "tests/test_inventory.py",
  "tests/test_algorithms.py": "tests/test_algorithms.py",
  "requirements.txt": "requirements.txt",
  "README.md": "README.md",
  "documentation/SOEN105_COMPREHENSIVE_PDLC_DOCUMENTATION.md": "documentation/SOEN105_COMPREHENSIVE_PDLC_DOCUMENTATION.md",
};

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const file = searchParams.get("file");

    if (!file) {
      // List available files
      return NextResponse.json({
        files: Object.keys(allowedFiles),
      });
    }

    const relPath = allowedFiles[file];
    if (!relPath) {
      return NextResponse.json({ error: "File not found" }, { status: 404 });
    }

    const fullPath = path.join(process.cwd(), "python_package", relPath);
    if (!fs.existsSync(fullPath)) {
      return NextResponse.json({ error: "File does not exist on disk" }, { status: 404 });
    }

    const content = fs.readFileSync(fullPath, "utf-8");
    return NextResponse.json({
      file,
      content,
      size: content.length,
      lines: content.split("\n").length,
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
