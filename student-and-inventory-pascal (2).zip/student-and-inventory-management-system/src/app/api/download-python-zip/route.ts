import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import JSZip from "jszip";

function addDirectoryToZip(zip: JSZip, localDirPath: string, zipDirPath: string) {
  if (!fs.existsSync(localDirPath)) return;
  const entries = fs.readdirSync(localDirPath, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(localDirPath, entry.name);
    const relativeZipPath = zipDirPath ? `${zipDirPath}/${entry.name}` : entry.name;

    if (entry.isDirectory()) {
      if (entry.name !== "__pycache__" && !entry.name.startsWith(".")) {
        addDirectoryToZip(zip, fullPath, relativeZipPath);
      }
    } else if (entry.isFile()) {
      const fileContent = fs.readFileSync(fullPath);
      zip.file(relativeZipPath, fileContent);
    }
  }
}

export async function GET() {
  try {
    const zip = new JSZip();
    const packageDir = path.join(process.cwd(), "python_package");

    const rootFolder = zip.folder("GROUP_4_PROJECT");
    if (!rootFolder) {
      throw new Error("Failed to create zip folder structure");
    }

    addDirectoryToZip(rootFolder, packageDir, "");

    const zipBuffer = await zip.generateAsync({
      type: "nodebuffer",
      compression: "DEFLATE",
      compressionOptions: { level: 9 },
    });

    return new NextResponse(new Uint8Array(zipBuffer), {
      status: 200,
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": 'attachment; filename="GROUP_4_PROJECT_PYTHON_SOEN105.zip"',
      },
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
