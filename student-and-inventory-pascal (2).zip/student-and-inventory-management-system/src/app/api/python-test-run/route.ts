import { NextResponse } from "next/server";
import { exec } from "child_process";
import util from "util";

const execPromise = util.promisify(exec);

export async function POST() {
  try {
    const startTime = Date.now();
    // Execute python unittest runner
    const { stdout, stderr } = await execPromise(
      "python3 -m unittest discover -s python_package/tests -v"
    );

    const duration = Date.now() - startTime;
    return NextResponse.json({
      success: true,
      output: stderr || stdout,
      durationMs: duration,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        output: error.stderr || error.stdout || error.message,
        error: "Unit tests failed or returned non-zero code",
      },
      { status: 500 }
    );
  }
}
