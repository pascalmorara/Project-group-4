import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { students, systemLogs } from "@/db/schema";
import { calculateAcademicGrade } from "@/lib/calculations";
import { eq, and, ne } from "drizzle-orm";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const numId = parseInt(id, 10);
    if (isNaN(numId)) {
      return NextResponse.json({ success: false, error: "Invalid student ID" }, { status: 400 });
    }

    const [student] = await db.select().from(students).where(eq(students.id, numId)).limit(1);
    if (!student) {
      return NextResponse.json({ success: false, error: "Student not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, student });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const numId = parseInt(id, 10);
    if (isNaN(numId)) {
      return NextResponse.json({ success: false, error: "Invalid student ID" }, { status: 400 });
    }

    const body = await req.json();
    const { registrationNumber, fullName, cat1, cat2, examination } = body;

    if (!registrationNumber || !registrationNumber.trim()) {
      return NextResponse.json({ success: false, error: "Registration number cannot be blank." }, { status: 400 });
    }
    if (!fullName || !fullName.trim()) {
      return NextResponse.json({ success: false, error: "Full name cannot be blank." }, { status: 400 });
    }

    const c1 = Number(cat1);
    const c2 = Number(cat2);
    const exam = Number(examination);

    if (isNaN(c1) || c1 < 0 || c1 > 100 || isNaN(c2) || c2 < 0 || c2 > 100 || isNaN(exam) || exam < 0 || exam > 100) {
      return NextResponse.json({ success: false, error: "Marks must be valid numbers between 0 and 100." }, { status: 400 });
    }

    const cleanRegNo = registrationNumber.trim().toUpperCase();

    // Check if another student has this reg number
    const duplicate = await db
      .select()
      .from(students)
      .where(and(eq(students.registrationNumber, cleanRegNo), ne(students.id, numId)))
      .limit(1);

    if (duplicate.length > 0) {
      return NextResponse.json(
        { success: false, error: `Registration number '${cleanRegNo}' is already used by another student.` },
        { status: 409 }
      );
    }

    const { totalScore, grade, status } = calculateAcademicGrade(c1, c2, exam);

    const [updated] = await db
      .update(students)
      .set({
        registrationNumber: cleanRegNo,
        fullName: fullName.trim(),
        cat1: c1,
        cat2: c2,
        examination: exam,
        totalScore,
        grade,
        status,
        updatedAt: new Date(),
      })
      .where(eq(students.id, numId))
      .returning();

    await db.insert(systemLogs).values({
      action: "STUDENT_UPDATED",
      module: "STUDENTS",
      details: `Updated student record for ${updated.fullName} (${updated.registrationNumber})`,
    });

    return NextResponse.json({ success: true, student: updated });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const numId = parseInt(id, 10);
    if (isNaN(numId)) {
      return NextResponse.json({ success: false, error: "Invalid student ID" }, { status: 400 });
    }

    const [existing] = await db.select().from(students).where(eq(students.id, numId)).limit(1);
    if (!existing) {
      return NextResponse.json({ success: false, error: "Student not found" }, { status: 404 });
    }

    await db.delete(students).where(eq(students.id, numId));

    await db.insert(systemLogs).values({
      action: "STUDENT_DELETED",
      module: "STUDENTS",
      details: `Deleted student record for ${existing.fullName} (${existing.registrationNumber})`,
    });

    return NextResponse.json({ success: true, message: `Student ${existing.fullName} deleted successfully.` });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
