import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { students, systemLogs } from "@/db/schema";
import { calculateAcademicGrade } from "@/lib/calculations";
import { desc, eq } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const query = searchParams.get("q")?.trim().toLowerCase();

    const allStudents = await db.select().from(students).orderBy(desc(students.createdAt));

    if (query) {
      const filtered = allStudents.filter(
        (s) =>
          s.registrationNumber.toLowerCase().includes(query) ||
          s.fullName.toLowerCase().includes(query) ||
          s.grade.toLowerCase() === query
      );
      return NextResponse.json({ success: true, students: filtered });
    }

    return NextResponse.json({ success: true, students: allStudents });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { registrationNumber, fullName, cat1, cat2, examination } = body;

    // Strict Validation
    if (!registrationNumber || typeof registrationNumber !== "string" || !registrationNumber.trim()) {
      return NextResponse.json(
        { success: false, error: "Student Registration Number is required and cannot be blank." },
        { status: 400 }
      );
    }

    if (!fullName || typeof fullName !== "string" || !fullName.trim()) {
      return NextResponse.json(
        { success: false, error: "Full Name is required and cannot be blank." },
        { status: 400 }
      );
    }

    const c1 = Number(cat1);
    const c2 = Number(cat2);
    const exam = Number(examination);

    if (isNaN(c1) || c1 < 0 || c1 > 100) {
      return NextResponse.json(
        { success: false, error: "CAT 1 marks must be a valid number between 0 and 100." },
        { status: 400 }
      );
    }

    if (isNaN(c2) || c2 < 0 || c2 > 100) {
      return NextResponse.json(
        { success: false, error: "CAT 2 marks must be a valid number between 0 and 100." },
        { status: 400 }
      );
    }

    if (isNaN(exam) || exam < 0 || exam > 100) {
      return NextResponse.json(
        { success: false, error: "Examination marks must be a valid number between 0 and 100." },
        { status: 400 }
      );
    }

    const cleanRegNo = registrationNumber.trim().toUpperCase();

    // Check duplicate
    const existing = await db
      .select()
      .from(students)
      .where(eq(students.registrationNumber, cleanRegNo))
      .limit(1);

    if (existing.length > 0) {
      return NextResponse.json(
        { success: false, error: `Student with Registration Number '${cleanRegNo}' already exists in SQLite/DB.` },
        { status: 409 }
      );
    }

    // Exact formula
    const { totalScore, grade, status } = calculateAcademicGrade(c1, c2, exam);

    const [newStudent] = await db
      .insert(students)
      .values({
        registrationNumber: cleanRegNo,
        fullName: fullName.trim(),
        cat1: c1,
        cat2: c2,
        examination: exam,
        totalScore,
        grade,
        status,
      })
      .returning();

    await db.insert(systemLogs).values({
      action: "STUDENT_REGISTERED",
      module: "STUDENTS",
      details: `Registered ${newStudent.fullName} (${newStudent.registrationNumber}) with final score ${totalScore} [${grade}]`,
    });

    return NextResponse.json({ success: true, student: newStudent }, { status: 201 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
